block = [
    "import",
    "eval",
    "banner",
    "echo",
    "cat",
    "lower",
    "upper",
    "system",
    "os",
    "breakpoint",
    ";",
    '"',
    "os",
    "_",
    "\\",
    "`",
    " ",
    "-",
    "!",
    "[",
    "]",
    "*",
    "%",
    "&",
    ">",
    "<",
    "+",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "0",
    "b",
    "s",
    "}",
    "{",
    ".py",
]

ascii2 = r"""
   _____              __         ____  __.                   .__            
  /     \ _____      |__|__ __  |    |/ _|____   ____   ____ |  |__ _____   
 /  \ /  \\__  \     |  |  |  \ |      < /  _ \ /    \ /  _ \|  |  \\__  \  
/    Y    \/ __ \_   |  |  |  / |    |  (  <_> )   |  (  <_> )   Y  \/ __ \_
\____|__  (____  /\__|  |____/  |____|__ \____/|___|  /\____/|___|  (____  /
        \/     \/\______|               \/          \/            \/     \/ 
"""

lagu = """
Ayo kawan kita bersama
menanam jagung di kebun kita
ambil cangkulmu, ambil pangkurmu
kita bekerja tak jemu-jemu
cangkul, cangkul, cangkul yang dalam
tanah yang longgar jagung kutanam
"""
